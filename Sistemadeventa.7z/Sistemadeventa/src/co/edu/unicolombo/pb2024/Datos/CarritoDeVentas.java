package co.edu.unicolombo.pb2024.Datos;

import java.util.ArrayList;

public class CarritoDeVentas {
    public ArrayList<Producto> productos;

    public CarritoDeVentas() {
        productos = new ArrayList<>();
    }
    
    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public void setProductos(ArrayList<Producto> productos) {
        this.productos = productos;
    }
    
    //Metodo para agregar un producto
    public void agregarProducto(Producto producto){
        productos.add(producto);
    }
    
    //Metodo para eliminar un producto
    public void eliminarProducto(Producto producto){
        productos.remove(producto);
    }
    
    //Metodo para calcular el total de los productos
    public double calcularTotal(){
        double total = 0;
        for (Producto producto : productos) {
            total += producto.getPrecio() * producto.getCantidad();
        }
        return total;
    }
}
