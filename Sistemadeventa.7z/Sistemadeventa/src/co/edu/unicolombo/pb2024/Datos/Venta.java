package co.edu.unicolombo.pb2024.Datos;

import java.util.ArrayList;

public class Venta {
    public int id;
    public String fechaVenta;
    public String periodoVenta;
    public ArrayList<Producto> productosVendidos;
    public ArrayList<Usuario> usuario;
    public ArrayList<Asistente_de_ventas> asistente;
    public double totalGastado;
    public int contadorCompras;

    public Venta(int id, String fechaVenta, String periodoVenta, 
            ArrayList<Producto> productosVendidos, 
            ArrayList<Usuario> usuario, 
            ArrayList<Asistente_de_ventas> asistente,
            double totalGastado, int contadorCompras) {
        
        this.id = id;
        this.fechaVenta = fechaVenta;
        this.periodoVenta = periodoVenta;
        this.productosVendidos = productosVendidos;
        this.usuario = usuario;
        this.asistente = asistente;
        this.totalGastado = totalGastado;
        this.contadorCompras = contadorCompras;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(String fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public String getPeriodoVenta() {
        return periodoVenta;
    }

    public void setPeriodoVenta(String periodoVenta) {
        this.periodoVenta = periodoVenta;
    }

    public ArrayList<Producto> getProductosVendidos() {
        return productosVendidos;
    }

    public void setProductosVendidos(ArrayList<Producto> productosVendidos) {
        this.productosVendidos = productosVendidos;
    }

    public ArrayList<Usuario> getUsuario() {
        return usuario;
    }

    public void setUsuario(ArrayList<Usuario> usuario) {
        this.usuario = usuario;
    }

    public ArrayList<Asistente_de_ventas> getAsistente() {
        return asistente;
    }

    public void setAsistente(ArrayList<Asistente_de_ventas> asistente) {
        this.asistente = asistente;
    }

    public double getTotalGastado() {
        return totalGastado;
    }

    public void setTotalGastado(double totalGastado) {
        this.totalGastado = totalGastado;
    }

    public int getContadorCompras() {
        return contadorCompras;
    }

    public void setContadorCompras(int contadorCompras) {
        this.contadorCompras = contadorCompras;
    }

    public void agregarProducto(Producto productoVendido) {
        productosVendidos.add(productoVendido);
        contadorCompras++;
    }
    public void aplicarDescuento() {
        if (contadorCompras >= 5) {
            double descuento = 0.20 * calcularTotalVenta(); // Calcular el descuento
            // Restar el descuento al precio total de la venta
            for (Producto producto : productosVendidos) {
                producto.setPrecio(producto.getPrecio() - descuento);
            }
        }
    }

    private double calcularTotalVenta() {
        return 0;
    }
}
