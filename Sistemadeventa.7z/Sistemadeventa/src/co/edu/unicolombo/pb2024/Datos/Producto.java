package co.edu.unicolombo.pb2024.Datos;

import co.edu.unicolombo.pb2024.ConexionBaseDatos.Conexion;
import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Producto {
    public double codigo;
    public String nombre;
    public double precio;
    public int cantidad;

    public Producto(double codigo, String nombre, double precio, int cantidad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public double getCodigo() {
        return codigo;
    }

    public void setCodigo(double codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    // Método para obtener todos los productos
    public static ArrayList<Producto> obtenerProductos() throws SQLException {
        ArrayList<Producto> productos = new ArrayList<>();
        String query = "SELECT codigo, nombre, precio, cantidad FROM productos";
        try (Connection connection = Conexion.getConnection();
            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery()) {
            System.out.println(rs);
            while (rs.next()) {
                double codigo = rs.getDouble("codigo"); 
                String nombre = rs.getString("nombre");
                double precio = rs.getDouble("precio");
                int cantidad = rs.getInt("cantidad");

                // Crear una nueva instancia de Producto y agregarla a la lista
                Producto producto = new Producto(codigo, nombre, precio, cantidad);
                productos.add(producto);
            }
        }
        return productos;
    }
    
//    public static void main(String[] args) throws SQLException {
//         try {
//            ArrayList<Producto> productos = obtenerProductos();;
//            // Imprimir los productos para verificar
//            for (Producto p : productos) {
//                System.out.println("Código: " + p.getCodigo() + ", Nombre: " + p.getNombre() + ", Precio: " + p.getPrecio() + 
//                        ", Cantidad: " + p.getCantidad());
//            }
//        } catch (SQLException e) {
//            e.printStackTrace(); // Manejo de errores
//        }
//        String imagenUrl = "C:\\Users\\ASUS\\OneDrive\\Documents\\Sistemadeventa\\src\\Imagenes\\Productos\\Base de maquillaje.jpeg";
//
//        // Crear el JFrame
//        JFrame frame = new JFrame("Mostrar Imagen");
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setSize(400, 400);
//        
//        // Cargar la imagen
//        ImageIcon imagenIcon = new ImageIcon(imagenUrl);
//
//        // Crear un JLabel y agregar la imagen
//        JLabel label = new JLabel(imagenIcon);
//        frame.getContentPane().add(label, BorderLayout.CENTER);
//
//        // Hacer visible el JFrame
//        frame.setVisible(true);
//
//    }
}
