package co.edu.unicolombo.pb2024.Datos;

import co.edu.unicolombo.pb2024.ConexionBaseDatos.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Asistente_de_ventas {
    protected String nombre;
    protected String apellido;
    protected String numCedula;
    @SuppressWarnings("unused")
    public String descripcion;
    public int numeroDeCaja;

    public Asistente_de_ventas(String nombre, String apellido, String numCedula) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.numCedula = numCedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNumCedula() {
        return numCedula;
    }

    public void setNumCedula(String numCedula) {
        this.numCedula = numCedula;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getNumeroDeCaja() {
        return numeroDeCaja;
    }

    public void setNumeroDeCaja(int numeroDeCaja) {
        this.numeroDeCaja = numeroDeCaja;
    }
    
     public ArrayList<Asistente_de_ventas> obtenerAsistentes() {
        ArrayList<Asistente_de_ventas> asistentes = new ArrayList<>();
        String query = "SELECT nombre, apellido, num_cedula, descripcion, numero_de_caja FROM asistentes";

        try (Connection connection = Conexion.getConnection();
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String apellido = rs.getString("apellido");
                String numCedula = rs.getString("num_cedula");
                String descripcion = rs.getString("descripcion");
                int numeroDeCaja = rs.getInt("numero_de_caja");

                Asistente_de_ventas asistente = new Asistente_de_ventas(nombre, apellido, numCedula);
                asistente.setDescripcion(descripcion);
                asistente.setNumeroDeCaja(numeroDeCaja);
                asistentes.add(asistente);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener asistentes: " + e.getMessage());
        }
        return asistentes;
    }
}
