package co.edu.unicolombo.pb2024.ConexionBaseDatos;

import co.edu.unicolombo.pb2024.Datos.Usuario;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Conexion {
    //creamos nuestras variables staticas
    private static final String url = "jdbc:mysql://localhost:3306/sistema de ventas?useSSL=false&serverTimezone=UTC";
    private static final String Usuario = "root";
    private static final String contraseña = "";
    
    public static Connection getConnection() throws SQLException {
        return (Connection) DriverManager.getConnection(url, Usuario, contraseña);
    }
    
    public static void guardarUsuariosEnBD(ArrayList<Usuario> usuarios) throws SQLException, ClassNotFoundException {
        // Creamos una variable de tipo Connection para la conexión a la base de datos
        Connection conexion = null;

        // Creamos variables de tipo PreparedStatement para ejecutar las consultas SQL
        PreparedStatement consultaVerificacion = null;
        PreparedStatement consultaInsercion = null;

        try {
            // Cargar el controlador de MySQL y establecer la conexión
            Class.forName("com.mysql.jdbc.Driver");
            conexion = (Connection) DriverManager.getConnection(url, Usuario, contraseña);

            // Consulta para verificar si existen duplicados (documento, teléfono o correo)
            String consultaVerificarDuplicados = "SELECT COUNT(*) FROM usuarios WHERE num_cedula = ? OR num_telefono = ? OR correo = ?";
            consultaVerificacion = (PreparedStatement) conexion.prepareStatement(consultaVerificarDuplicados);

            // Consulta para insertar nuevos usuarios
            String consultaInsertarUsuario = "INSERT INTO usuarios (nombre, apellido, num_cedula, num_telefono, correo, contraseña, saldo) VALUES (?, ?, ?, ?, ?, ?, ?)";
            consultaInsercion = (PreparedStatement) conexion.prepareStatement(consultaInsertarUsuario);

            // Recorremos el ArrayList de usuarios
            for (Usuario usuario : usuarios) {
                // Configuramos los parámetros para la consulta de verificación de duplicados
                consultaVerificacion.setString(1, usuario.getNumCedula());
                consultaVerificacion.setString(2, usuario.getNumTelefono());
                consultaVerificacion.setString(3, usuario.getCorreo());

                // Ejecutamos la consulta para verificar duplicados
                ResultSet resultado = consultaVerificacion.executeQuery();
                if (resultado.next()) {
                    int contador = resultado.getInt(1);
                    if (contador > 0) {
                        // Datos duplicados encontrados, mostramos un mensaje y pasamos al siguiente Usuario
                        JOptionPane.showMessageDialog(null, "Ya existe un usuario registrado con estos datos:\n" +
                            "Documento: " + usuario.getNumCedula() + "\n" +
                            "Teléfono: " + usuario.getNumTelefono() + "\n" +
                            "Correo: " + usuario.getCorreo());
                        continue; // Saltamos la inserción si encontramos duplicados
                    }
                }

                // Si no hay duplicados, procedemos a insertar el nuevo Usuario
                consultaInsercion.setString(1, usuario.getNombre());
                consultaInsercion.setString(2, usuario.getApellido());
                consultaInsercion.setString(3, usuario.getNumCedula());
                consultaInsercion.setString(4, usuario.getNumTelefono());
                consultaInsercion.setString(5, usuario.getCorreo());
                consultaInsercion.setString(6, usuario.getContraseña());
                consultaInsercion.setDouble(7, usuario.getSaldoUsuario());

                // Ejecutamos la consulta de inserción
                consultaInsercion.executeUpdate();
                JOptionPane.showMessageDialog(null, "El usuario " + usuario.getNombre() + " ha sido guardado en la base de datos.");
            }

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            // Cerramos los recursos en el bloque finally
            if (consultaVerificacion != null) {
                consultaVerificacion.close();
            }
            if (consultaInsercion != null) {
                consultaInsercion.close();
            }
            if (conexion != null) {
                conexion.close();
            }
        }
    }
    
    public static ArrayList<Usuario> recuperarUsuariosDeBD() throws SQLException {
        Connection conexion = null;
        PreparedStatement sentencia = null;
        ResultSet resultado = null;

        // Usamos un ArrayList para almacenar los usuarios recuperados
        ArrayList<Usuario> usuarios = new ArrayList<>();

        try {
            // Cargamos el controlador de MySQL
            Class.forName("com.mysql.jdbc.Driver"); // Cambia esto si usas un controlador diferente
            // Establecemos la conexión
            conexion = (Connection) DriverManager.getConnection(url, Usuario, contraseña);

            // Consulta SQL para seleccionar todos los usuarios
            String consulta = "SELECT * FROM usuarios";
            sentencia = (PreparedStatement) conexion.prepareStatement(consulta);
            resultado = sentencia.executeQuery();

            // Recorremos el resultado de la consulta
            while (resultado.next()) {
                // Recuperamos los datos de cada usuario
                String nombre = resultado.getString("nombre");
                String apellido = resultado.getString("apellido");
                String numCedula = resultado.getString("num_cedula");
                String numTelefono = resultado.getString("num_telefono");
                String correo = resultado.getString("correo");
                String contrasena = resultado.getString("contraseña");
                double saldo = resultado.getDouble("saldo");

                // Creamos un nuevo objeto Usuario y lo agregamos al ArrayList
                Usuario usuario = new Usuario(nombre, apellido, 
                                            numCedula, correo, 
                                            contrasena, numTelefono, saldo);
                usuarios.add(usuario);
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            // Cerramos los recursos
            if (resultado != null) {
                resultado.close();
            }
            if (sentencia != null) {
                sentencia.close();
            }
            if (conexion != null) {
                conexion.close();
            }
        }

        return usuarios; // Devolvemos la lista de usuarios
    }
    
    //Metodo para obtener el numero de usuarios guardados en la base de datos
    public static int obtenerNumeroUsuariosDesdeBD() throws SQLException, ClassNotFoundException {
        Connection conexion = null;
        PreparedStatement sentencia = null;
        ResultSet resultado = null;
        int numeroUsuarios = 0;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = (Connection) DriverManager.getConnection(url, Usuario, contraseña);

            String consulta = "SELECT COUNT(*) FROM usuarios";
            sentencia = (PreparedStatement) conexion.prepareStatement(consulta);
            resultado = sentencia.executeQuery();

            if (resultado.next()) {
                numeroUsuarios = resultado.getInt(1);
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            // Asegúrate de cerrar los recursos
            if (resultado != null) {
                resultado.close();
            }
            if (sentencia != null) {
                sentencia.close();
            }
            if (conexion != null) {
                conexion.close();
            }
        }

        return numeroUsuarios;
    }
    
}
//    //Metodo para  guardar el saldo en la base de datos dependiento de si el usuario recarga o retira
//    public static void guardarSaldoEnBD(HashMap<String, Recarga_Retiro> recarga_retiro, boolean esRecarga) throws SQLException, ClassNotFoundException {
//        Connection con = null;
//        PreparedStatement sentencia = null;
//
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bd_usuarios?useSSL=false&serverTimezone=UTC", "root", "");
//
//            String consulta;
//            if (esRecarga) {
//                consulta = "UPDATE usuarios SET saldo = saldo + ? WHERE correo = ?";
//            } else {
//                consulta = "UPDATE usuarios SET saldo = saldo - ? WHERE correo = ?";
//            }
//            sentencia = con.prepareStatement(consulta);
//
//            for (Recarga_Retiro saldo : recarga_retiro.values()) {
//                if (saldo.getUsuario() != null && saldo.getUsuario().getCorreo() != null) {
//                    sentencia.setDouble(1, saldo.getSaldo()); // Saldo recargado o retirado
//                    sentencia.setString(2, saldo.getUsuario().getCorreo()); // Correo del usuario
//                    sentencia.executeUpdate();
//                }
//            }
//            JOptionPane.showMessageDialog(null, "El saldo ha sido actualizado en la base de datos.");
//        } catch (SQLException e) {
//            System.out.println("Error: " + e.getMessage());
//        } finally {
//            // Cerramos los recursos
//            if (sentencia != null) {
//                sentencia.close();
//            }
//            if (con != null) {
//                con.close();
//            }
//        }
//    }
//    
//    // Metodo para Cargar el saldo que esta guardado en la base de datos
//    public static double obtenerSaldoDeBD(String correo) throws SQLException, ClassNotFoundException {
//        Connection con = null;
//        PreparedStatement sentencia = null;
//        ResultSet resultado = null;
//        double saldo = 0.0;
//
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bd_usuarios?useSSL=false&serverTimezone=UTC", "root", "");
//
//            String consulta = "SELECT Saldo FROM usuarios WHERE correo = ?";
//            sentencia = con.prepareStatement(consulta);
//            sentencia.setString(1, correo);
//            resultado = sentencia.executeQuery();
//
//            if (resultado.next()) {
//                saldo = resultado.getDouble("Saldo");
//            }
//        } catch (SQLException e) {
//            System.out.println("Error: " + e.getMessage());
//        } finally {
//            // Cerramos los recursos
//            if (resultado != null) {
//                resultado.close();
//            }
//            if (sentencia != null) {
//                sentencia.close();
//            }
//            if (con != null) {
//                con.close();
//            }
//        }
//        return saldo;
//    }
//    
////-----------------------------------------------------------------------------------------------------------------
//    
//    public static final String url = "jdbc:mysql://localhost:3306/bd_usuarios";
//    public static final String Usuario = "root";
//    public static final String contraseña = "";
//    
//    public static int obtenerNumeroUsuarios() throws SQLException, ClassNotFoundException {
//        Connection conexion = null;
//        PreparedStatement sentencia = null;
//        ResultSet resultado = null;
//        int numeroUsuarios = 0;
//        
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            conexion = DriverManager.getConnection(url,Usuario,contraseña);
//
//            String consulta = "SELECT COUNT(*) FROM usuarios";
//            sentencia = conexion.prepareStatement(consulta);
//            resultado = sentencia.executeQuery();
//
//            if (resultado.next()) {
//                numeroUsuarios = resultado.getInt(1);
//            }
//        } catch (ClassNotFoundException | SQLException e) {
//            System.out.println("Error: " + e.getMessage());
//        } finally {
//            if (resultado != null) {
//                resultado.close();
//            }
//            if (sentencia != null) {
//                sentencia.close();
//            }
//            if (conexion != null) {
//                conexion.close();
//            }
//        }
//
//        return numeroUsuarios;
//    }
//    
//    // metodo para eliminar usurios desde la base de datos precionando el boton eliminar en la ventana miCuenta
//    public static void eliminarUsuario(String correo) throws SQLException {
//        Connection conexion = null;
//        PreparedStatement sentencia = null;
//
//        try {
//            // Establece la conexión a la base de datos
//            conexion = DriverManager.getConnection(url,Usuario,contraseña);
//
//            // Prepara la sentencia SQL para eliminar el Usuario
//            String consulta = "DELETE FROM usuarios WHERE correo = ?";
//            sentencia = conexion.prepareStatement(consulta);
//            sentencia.setString(1, correo);
//
//            // Ejecuta la sentencia SQL
//            sentencia.executeUpdate();
//        } finally {
//            // Cierra la conexión y la sentencia
//            if (sentencia != null) {
//                sentencia.close();
//            }
//            if (conexion != null) {
//                conexion.close();
//            }
//        }
//    }
//        
//    //Metodo para traerlos de vuelta a los usuarios al programa
//    public static HashMap<String, Usuario> recuperarUsuariosDeBD() throws SQLException {
//        //Creamos un variable de tipo (Connection)
//        Connection conexion = null;
//        /*declaramos una variable llamada sentencia que sera utilizada para crear
//        una sentencia preparada (prepared sentencia) en la base de datos. */
//        PreparedStatement sentencia = null;
//        
//        ResultSet resultado = null;
//                
//        HashMap<String, Usuario> usuarios = new HashMap<>();
//        
//       try {
//            Class.forName("com.mysql.jdbc.Driver");
//            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/bd_usuarios", "root", "");
//
//            String consulta = "SELECT * FROM usuarios ";
//            sentencia = conexion.prepareStatement(consulta);
//            resultado = sentencia.executeQuery();
//
//            while (resultado.next()) {
//                String nombre = resultado.getString("nombre");
//                String apellidos = resultado.getString("apellido");
//                String documento = resultado.getString("documento");
//                String telefono = resultado.getString("telefono");
//                String correoUsuario = resultado.getString("correo");
//                String contraseñaUsuario = resultado.getString("contraseña");
//                
//                //Depurando
////                System.out.println(nombre);
////                System.out.println(correoUsuario);
////                System.out.println(contraseñaUsuario);
//                
//                Usuario usuario = new Usuario();
//                usuario.setNombre(nombre);
//                usuario.setApellidos(apellidos);
//                usuario.setDocumento(documento);
//                usuario.setTelefono(telefono);
//                usuario.setCorreo(correoUsuario);
//                usuario.setContraseña(contraseñaUsuario);
//                usuarios.put(correoUsuario, usuario);
//            }
//        } catch (ClassNotFoundException | SQLException e) {
//            System.out.println("Error: " + e.getMessage());
//        } finally {
//            if (resultado != null) {
//                resultado.close();
//            }
//            if (sentencia != null) {
//                sentencia.close();
//            }
//            if (conexion != null) {
//                conexion.close();
//            }
//        }
//        return usuarios;
//    }
//    
//    
//    //    public Conexion_BaseDatos(){
////        try {
////            Class.forName("com.mysql.jdbc.Driver");
////            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bd_usuarios", "root", "");
////        } catch (ClassNotFoundException | SQLException e) {
////            System.out.println("Error: " + e.getMessage());
////        }
////    }


