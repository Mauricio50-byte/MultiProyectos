-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-11-2024 a las 21:25:41
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema de ventas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistentes`
--

CREATE TABLE `asistentes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `num_cedula` varchar(20) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `numero_de_caja` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `asistentes`
--

INSERT INTO `asistentes` (`id`, `nombre`, `apellido`, `num_cedula`, `descripcion`, `numero_de_caja`) VALUES
(1, 'Ana', 'González', '1023456789', 'Asistente amable y profesional.', 10),
(2, 'Luis', 'Pérez', '2034567890', 'Experto en maquillaje para eventos.', 12),
(3, 'María', 'Rodríguez', '3045678901', 'Proporciona atención personalizada.', 5),
(4, 'José', 'Martínez', '4056789012', 'Siempre dispuesto a ayudar.', 22),
(5, 'Laura', 'Sánchez', '5067890123', 'Conocimientos en tratamientos faciales.', 14),
(6, 'Carlos', 'Torres', '6078901234', 'Maquillaje para ocasiones especiales.', 30),
(7, 'Isabel', 'Morales', '7089012345', 'Proporciona una excelente experiencia al cliente.', 8),
(8, 'David', 'Jiménez', '8090123456', 'Siempre actualizado con las tendencias.', 1),
(9, 'Valeria', 'Castro', '9012345678', 'Asistente con mucha creatividad.', 17),
(10, 'Pedro', 'López', '1234567890', 'Enfocado en la satisfacción del cliente.', 25);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `codigo` decimal(10,2) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `codigo`, `nombre`, `precio`, `cantidad`) VALUES
(1, 100001.00, 'Base de Maquillaje', 25900.00, 100),
(2, 100002.00, 'Corrector', 15400.00, 150),
(3, 100003.00, 'Polvo Compacto', 18900.00, 120),
(4, 100004.00, 'Sombras de Ojos', 22900.00, 80),
(5, 100005.00, 'Delineador', 10900.00, 200),
(6, 100006.00, 'Máscara de Pestañas', 12400.00, 110),
(7, 100007.00, 'Rubor', 17900.00, 130),
(8, 100008.00, 'Iluminador', 19900.00, 90),
(9, 100009.00, 'Lápiz Labial', 13400.00, 160),
(10, 100010.00, 'Brillo Labial', 11900.00, 140),
(11, 100011.00, 'Spray Fijador', 20900.00, 75),
(12, 100012.00, 'Espejo de Maquillaje', 9990.00, 300),
(13, 100013.00, 'Esponja de Maquillaje', 5990.00, 200),
(14, 100014.00, 'Pinceles de Maquillaje', 25400.00, 50),
(15, 100015.00, 'Paleta de Sombras', 30900.00, 60),
(16, 100016.00, 'Cuidado de la Piel', 29900.00, 80),
(17, 100017.00, 'Crema Hidratante', 15900.00, 95),
(18, 100018.00, 'Tónico Facial', 12900.00, 110),
(19, 100019.00, 'Exfoliante Facial', 18400.00, 70),
(20, 100020.00, 'Serum Antiedad', 35900.00, 55),
(21, 100021.00, 'Kit de Maquillaje', 60900.00, 30),
(22, 100022.00, 'Crema Solar', 20400.00, 100),
(23, 100023.00, 'Mascarilla Facial', 14900.00, 140),
(24, 100024.00, 'Lápiz de Cejas', 12400.00, 120),
(25, 100025.00, 'Gel para Cejas', 13900.00, 130),
(26, 100026.00, 'Cremas de Noche', 27900.00, 65),
(27, 100027.00, 'Cremas de Día', 28900.00, 75),
(28, 100028.00, 'Aguja para Cejas', 8490.00, 200),
(29, 100029.00, 'Pintalabios Mate', 16400.00, 115),
(30, 100030.00, 'Pintalabios Brillante', 16900.00, 110),
(31, 100031.00, 'Crema para Ojos', 22400.00, 85),
(32, 100032.00, 'Aceite Facial', 24900.00, 90),
(33, 100033.00, 'Paquete de Maquillaje', 70400.00, 25),
(34, 100034.00, 'Polvo Suelto', 19400.00, 120),
(35, 100035.00, 'Base de Maquillaje Líquida', 27400.00, 80),
(36, 100036.00, 'Delineador Líquido', 11400.00, 140),
(37, 100037.00, 'Esmalte de Uñas', 8990.00, 200),
(38, 100038.00, 'Quita Esmalte', 5490.00, 160),
(39, 100039.00, 'Lápiz de Ojos', 9490.00, 150),
(40, 100040.00, 'Gel Limpiador Facial', 15900.00, 130),
(41, 100041.00, 'Crema Anti-Acné', 22900.00, 75),
(42, 100042.00, 'Crema para Piel Sensible', 18400.00, 100),
(43, 100043.00, 'Protector Labial', 6490.00, 300),
(44, 100044.00, 'Lápiz Iluminador', 10900.00, 140),
(45, 100045.00, 'Cuidado Capilar', 30900.00, 50),
(46, 100046.00, 'Acondicionador', 25400.00, 70),
(47, 100047.00, 'Champú', 24900.00, 90),
(48, 100048.00, 'Secador de Cabello', 45900.00, 30),
(49, 100049.00, 'Plancha de Cabello', 55900.00, 25),
(50, 100050.00, 'Curling Iron', 50900.00, 20),
(51, 100051.00, 'Peine Desenredante', 3990.00, 200),
(52, 100052.00, 'Tijeras de Peluquería', 12900.00, 100),
(53, 100053.00, 'Tinte para Cabello', 15900.00, 150),
(54, 100054.00, 'Serum para Cabello', 19900.00, 90),
(55, 100055.00, 'Gel para Peinar', 8990.00, 130),
(56, 100056.00, 'Laca para Cabello', 7990.00, 150),
(57, 100057.00, 'Spray Texturizador', 10490.00, 100),
(58, 100058.00, 'Cera para Cabello', 9490.00, 120),
(59, 100059.00, 'Brocha para Polvo', 11990.00, 80),
(60, 100060.00, 'Brocha para Base', 13990.00, 70),
(61, 100061.00, 'Pincel para Detalles', 8990.00, 140),
(62, 100062.00, 'Estuche de Maquillaje', 15900.00, 50),
(63, 100063.00, 'Cinta Adhesiva', 3490.00, 200),
(64, 100064.00, 'Eyeliner en Gel', 10490.00, 110),
(65, 100065.00, 'Fijador de Maquillaje', 19900.00, 85),
(66, 100066.00, 'Tiras para Pestañas', 15400.00, 60),
(67, 100067.00, 'Pestañas Postizas', 12900.00, 75),
(68, 100068.00, 'Pinzas de Cejas', 6990.00, 120),
(69, 100069.00, 'Cinta para Cejas', 8490.00, 130),
(70, 100070.00, 'Cepillo para Pestañas', 4990.00, 200),
(71, 100071.00, 'Jabón para Piel', 3990.00, 250),
(72, 100072.00, 'Limpiador de Brochas', 6490.00, 90),
(73, 100073.00, 'Desmaquillante', 10900.00, 100),
(74, 100074.00, 'Paño Desmaquillante', 5490.00, 150),
(75, 100075.00, 'Tónico para Cabello', 14900.00, 80),
(76, 100076.00, 'Cuidado para Uñas', 9990.00, 200),
(77, 100077.00, 'Crema para Pies', 11990.00, 90),
(78, 100078.00, 'Gel para Manos', 5990.00, 140),
(79, 100079.00, 'Cremas para Manos', 15400.00, 70),
(80, 100080.00, 'Kit de Cuidado Personal', 45900.00, 30),
(81, 100081.00, 'Spray Corporal', 12900.00, 120),
(82, 100082.00, 'Perfume', 35900.00, 40),
(83, 100083.00, 'Desodorante', 7990.00, 200),
(84, 100084.00, 'Gel para Baño', 8990.00, 150),
(85, 100085.00, 'Crema para Cuerpo', 10490.00, 100),
(86, 100086.00, 'Tónico para Piel', 9490.00, 110),
(87, 100087.00, 'Bruma Facial', 15900.00, 85),
(88, 100088.00, 'Gel Antibacterial', 4990.00, 200),
(89, 100089.00, 'Crema de Afeitar', 5490.00, 160),
(90, 100090.00, 'Espuma de Afeitar', 7990.00, 140),
(91, 100091.00, 'After Shave', 12490.00, 90),
(92, 100092.00, 'Pasta Dental', 2990.00, 250),
(93, 100093.00, 'Cepillo Dental', 3490.00, 200),
(94, 100094.00, 'Hilo Dental', 1990.00, 300),
(95, 100095.00, 'Enjuague Bucal', 4490.00, 150),
(96, 100096.00, 'Bálsamo para Labios', 2990.00, 200),
(97, 100097.00, 'Desmaquillante de Ojos', 10900.00, 80),
(98, 100098.00, 'Espejo de Maquillaje con Luz', 25900.00, 60),
(99, 100099.00, 'Pañuelos Desmaquillantes', 8490.00, 140),
(100, 100100.00, 'Cuidado de Barba', 15900.00, 70);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `num_cedula` varchar(20) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `contraseña` varchar(100) DEFAULT NULL,
  `num_telefono` varchar(15) DEFAULT NULL,
  `saldo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellido`, `num_cedula`, `correo`, `contraseña`, `num_telefono`, `saldo`) VALUES
(1, 'mauricio andres', 'vergara fonseca', '1051736741', 'mauro@gmail.com', '0109', '3215017983', '20000000');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `codigo_producto` varchar(50) NOT NULL,
  `nombre_producto` varchar(255) NOT NULL,
  `precio_producto` decimal(10,2) NOT NULL,
  `fecha_venta` date NOT NULL,
  `periodo_venta` varchar(50) DEFAULT NULL,
  `num_cedula` varchar(20) NOT NULL,
  `nombre_usuario` varchar(255) NOT NULL,
  `asistente_encargado` varchar(255) NOT NULL,
  `total_gastado` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asistentes`
--
ALTER TABLE `asistentes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `num_cedula` (`num_cedula`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `num_cedula` (`num_cedula`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asistentes`
--
ALTER TABLE `asistentes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
